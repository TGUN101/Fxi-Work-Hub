# Android APK build

This project includes `.github/workflows/build-android-apk.yml`.

When pushed to a GitHub repository, GitHub Actions will:

1. Install Node, Java, and the Android SDK.
2. Install the Expo dependencies.
3. Generate the native Android project.
4. Build a debug APK.
5. Upload `FXI-Work-Hub-v0.1.0.apk` as a GitHub Actions artifact.

Android package ID: `com.tyler.fxiworkhub`

The debug APK is intended for direct testing on an Android phone and is not a Play Store release build.
