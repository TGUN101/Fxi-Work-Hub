import React, { useEffect, useState } from 'react';
import { StatusBar, StyleSheet, Text, View } from 'react-native';
import { TabBar } from './src/components/TabBar';
import { initDb } from './src/lib/db';
import { FilesScreen } from './src/screens/FilesScreen';
import { HomeScreen } from './src/screens/HomeScreen';
import { NotesScreen } from './src/screens/NotesScreen';
import { ScannerScreen } from './src/screens/ScannerScreen';
import type { TabKey } from './src/types';

export default function App() {
  const [tab, setTab] = useState<TabKey>('home');
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    initDb().then(() => setReady(true)).catch((e) => setError(String(e)));
  }, []);

  if (!ready) {
    return (
      <View style={styles.loading}>
        <StatusBar barStyle="light-content" backgroundColor="#0b0c0f" />
        <Text style={styles.brand}>FXI WORK HUB</Text>
        <Text style={styles.loadingText}>{error || 'Loading local work database…'}</Text>
      </View>
    );
  }

  return (
    <View style={styles.app}>
      <StatusBar barStyle="light-content" backgroundColor="#0b0c0f" />
      <View style={styles.page}>
        {tab === 'home' && <HomeScreen goTo={setTab} />}
        {tab === 'scan' && <ScannerScreen />}
        {tab === 'notes' && <NotesScreen />}
        {tab === 'files' && <FilesScreen />}
      </View>
      <TabBar active={tab} onChange={setTab} />
    </View>
  );
}

const styles = StyleSheet.create({
  app: { flex: 1, backgroundColor: '#0b0c0f' },
  page: { flex: 1 },
  loading: { flex: 1, backgroundColor: '#0b0c0f', alignItems: 'center', justifyContent: 'center', padding: 24 },
  brand: { color: '#fff', fontSize: 24, fontWeight: '900', letterSpacing: 1.2 },
  loadingText: { color: '#8e929c', marginTop: 9, textAlign: 'center' },
});
