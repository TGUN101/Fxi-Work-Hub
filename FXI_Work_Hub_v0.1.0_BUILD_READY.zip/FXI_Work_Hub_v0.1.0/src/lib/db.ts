import * as SQLite from 'expo-sqlite';
import type { BarcodeScan, WorkFile, WorkNote } from '../types';

let dbPromise: ReturnType<typeof SQLite.openDatabaseAsync> | null = null;

function getDb() {
  if (!dbPromise) dbPromise = SQLite.openDatabaseAsync('fxi_work_hub.db');
  return dbPromise;
}

export async function initDb() {
  const db = await getDb();
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    CREATE TABLE IF NOT EXISTS barcode_scans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      value TEXT NOT NULL,
      format TEXT NOT NULL,
      scanned_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_barcode_scans_recent
      ON barcode_scans(scanned_at DESC);

    CREATE TABLE IF NOT EXISTS work_notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_work_notes_recent
      ON work_notes(created_at DESC);

    CREATE TABLE IF NOT EXISTS work_files (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL CHECK(kind IN ('photo','manual')),
      name TEXT NOT NULL,
      uri TEXT NOT NULL,
      mime_type TEXT,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_work_files_recent
      ON work_files(created_at DESC);
  `);
}

export async function addScan(value: string, format: string) {
  const db = await getDb();
  const scannedAt = Date.now();
  await db.runAsync(
    'INSERT INTO barcode_scans (value, format, scanned_at) VALUES (?, ?, ?)',
    value,
    format,
    scannedAt
  );
  return scannedAt;
}

export async function getRecentScans(limit = 100) {
  const db = await getDb();
  return db.getAllAsync<BarcodeScan>(
    'SELECT id, value, format, scanned_at FROM barcode_scans ORDER BY scanned_at DESC, id DESC LIMIT ?',
    limit
  );
}

export async function deleteScan(id: number) {
  const db = await getDb();
  await db.runAsync('DELETE FROM barcode_scans WHERE id = ?', id);
}

export async function addNote(title: string, body: string) {
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO work_notes (title, body, created_at) VALUES (?, ?, ?)',
    title.trim() || 'Work Note',
    body.trim(),
    Date.now()
  );
}

export async function getNotes(limit = 100) {
  const db = await getDb();
  return db.getAllAsync<WorkNote>(
    'SELECT id, title, body, created_at FROM work_notes ORDER BY created_at DESC, id DESC LIMIT ?',
    limit
  );
}

export async function addWorkFile(file: Omit<WorkFile, 'id' | 'created_at'>) {
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO work_files (kind, name, uri, mime_type, created_at) VALUES (?, ?, ?, ?, ?)',
    file.kind,
    file.name,
    file.uri,
    file.mime_type,
    Date.now()
  );
}

export async function getWorkFiles(limit = 200) {
  const db = await getDb();
  return db.getAllAsync<WorkFile>(
    'SELECT id, kind, name, uri, mime_type, created_at FROM work_files ORDER BY created_at DESC, id DESC LIMIT ?',
    limit
  );
}

export async function getCounts() {
  const db = await getDb();
  const scans = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM barcode_scans');
  const notes = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM work_notes');
  const files = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM work_files');
  return {
    scans: scans?.count ?? 0,
    notes: notes?.count ?? 0,
    files: files?.count ?? 0,
  };
}
