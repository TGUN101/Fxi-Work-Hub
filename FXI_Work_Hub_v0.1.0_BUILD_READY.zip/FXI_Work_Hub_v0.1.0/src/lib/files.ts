import { Directory, File, Paths } from 'expo-file-system';

function rootDirectory() {
  const dir = new Directory(Paths.document, 'FXIWorkHub');
  dir.create({ idempotent: true, intermediates: true });
  return dir;
}

function childDirectory(name: string) {
  const dir = new Directory(rootDirectory(), name);
  dir.create({ idempotent: true, intermediates: true });
  return dir;
}

function safeName(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]+/g, '_').slice(0, 100) || 'file';
}

export async function copyIntoApp(
  sourceUri: string,
  folder: 'photos' | 'manuals',
  originalName: string
) {
  const source = new File(sourceUri);
  const filename = `${Date.now()}_${safeName(originalName)}`;
  const destination = new File(childDirectory(folder), filename);
  await source.copy(destination, { overwrite: false });
  return destination.uri;
}
