import React, { useCallback, useEffect, useState } from 'react';
import { Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import { Screen } from '../components/Layout';
import { addWorkFile, getWorkFiles } from '../lib/db';
import { copyIntoApp } from '../lib/files';
import type { WorkFile } from '../types';

export function FilesScreen() {
  const [files, setFiles] = useState<WorkFile[]>([]);
  const refresh = useCallback(async () => setFiles(await getWorkFiles()), []);
  useEffect(() => { void refresh(); }, [refresh]);

  const takePhoto = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      Alert.alert('Camera permission needed');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: 0.85 });
    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];
    const name = asset.fileName || `work_photo_${Date.now()}.jpg`;
    const uri = await copyIntoApp(asset.uri, 'photos', name);
    await addWorkFile({ kind: 'photo', name, uri, mime_type: asset.mimeType ?? 'image/jpeg' });
    await refresh();
  };

  const addManual = async () => {
    const result = await DocumentPicker.getDocumentAsync({
      type: ['application/pdf', 'text/plain', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
      copyToCacheDirectory: true,
    });
    if (result.canceled || !result.assets?.[0]) return;
    const asset = result.assets[0];
    const uri = await copyIntoApp(asset.uri, 'manuals', asset.name);
    await addWorkFile({ kind: 'manual', name: asset.name, uri, mime_type: asset.mimeType ?? null });
    await refresh();
  };

  return (
    <Screen title="Photos & Manuals">
      <FlatList
        data={files}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View>
            <View style={styles.actions}>
              <Pressable style={styles.action} onPress={takePhoto}>
                <Text style={styles.actionTitle}>TAKE WORK PHOTO</Text>
                <Text style={styles.actionSub}>Camera → saved inside app</Text>
              </Pressable>
              <Pressable style={styles.action} onPress={addManual}>
                <Text style={styles.actionTitle}>ADD MANUAL</Text>
                <Text style={styles.actionSub}>PDF, Word or text file</Text>
              </Pressable>
            </View>
            <Text style={styles.section}>Stored Files</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.fileRow}>
            <View style={styles.fileIcon}><Text style={styles.fileGlyph}>{item.kind === 'photo' ? '▧' : '▤'}</Text></View>
            <View style={styles.fileMain}>
              <Text numberOfLines={1} style={styles.fileName}>{item.name}</Text>
              <Text style={styles.fileMeta}>{item.kind.toUpperCase()}  •  {new Date(item.created_at).toLocaleString()}</Text>
            </View>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No photos or manuals saved yet.</Text>}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 30 },
  actions: { gap: 9 },
  action: { backgroundColor: '#17191f', borderRadius: 14, padding: 17, borderWidth: 1, borderColor: '#2f323a' },
  actionTitle: { color: '#fff', fontSize: 15, fontWeight: '900' },
  actionSub: { color: '#8d919b', fontSize: 11, marginTop: 4 },
  section: { color: '#fff', fontSize: 17, fontWeight: '800', marginTop: 24, marginBottom: 8 },
  fileRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#15171c', borderRadius: 12, padding: 12, marginBottom: 8 },
  fileIcon: { width: 42, height: 42, borderRadius: 10, backgroundColor: '#24272e', alignItems: 'center', justifyContent: 'center' },
  fileGlyph: { color: '#fff', fontSize: 20 },
  fileMain: { flex: 1, marginLeft: 11 },
  fileName: { color: '#fff', fontSize: 14, fontWeight: '700' },
  fileMeta: { color: '#777b85', fontSize: 10, marginTop: 4 },
  empty: { color: '#8f939e', paddingVertical: 18 },
});
