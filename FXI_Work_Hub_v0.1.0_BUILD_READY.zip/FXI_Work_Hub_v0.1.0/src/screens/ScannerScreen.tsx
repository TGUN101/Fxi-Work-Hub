import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { CameraView, useCameraPermissions, type BarcodeScanningResult } from 'expo-camera';
import { Screen } from '../components/Layout';
import { ScanRow } from '../components/ScanRow';
import { addScan, getRecentScans } from '../lib/db';
import type { BarcodeScan } from '../types';

export function ScannerScreen() {
  const [permission, requestPermission] = useCameraPermissions();
  const [scans, setScans] = useState<BarcodeScan[]>([]);
  const [paused, setPaused] = useState(false);
  const [torch, setTorch] = useState(false);
  const [lastSaved, setLastSaved] = useState<string>('');
  const guardRef = useRef<{ value: string; time: number }>({ value: '', time: 0 });

  const refresh = useCallback(async () => setScans(await getRecentScans(100)), []);
  useEffect(() => { void refresh(); }, [refresh]);

  const onBarcodeScanned = async (result: BarcodeScanningResult) => {
    if (paused) return;
    const value = result.data?.trim();
    if (!value) return;
    const now = Date.now();
    if (guardRef.current.value === value && now - guardRef.current.time < 2500) return;
    guardRef.current = { value, time: now };
    setPaused(true);
    await addScan(value, result.type ?? 'unknown');
    setLastSaved(value);
    await refresh();
    setTimeout(() => setPaused(false), 850);
  };

  return (
    <Screen title="SAP Barcode Scanner">
      <View style={styles.container}>
        <View style={styles.cameraWrap}>
          {!permission ? (
            <View style={styles.permissionBox}><Text style={styles.muted}>Checking camera permission…</Text></View>
          ) : !permission.granted ? (
            <View style={styles.permissionBox}>
              <Text style={styles.permissionTitle}>Camera permission needed</Text>
              <Pressable style={styles.button} onPress={requestPermission}><Text style={styles.buttonText}>ALLOW CAMERA</Text></Pressable>
            </View>
          ) : (
            <CameraView
              style={StyleSheet.absoluteFill}
              facing="back"
              enableTorch={torch}
              onBarcodeScanned={paused ? undefined : onBarcodeScanned}
              barcodeScannerSettings={{
                barcodeTypes: ['code128', 'code39', 'ean13', 'ean8', 'upc_a', 'upc_e', 'itf14', 'pdf417', 'datamatrix', 'qr'],
              }}
            />
          )}
          <View pointerEvents="none" style={styles.frame} />
          <View style={styles.cameraControls}>
            <Pressable style={styles.smallButton} onPress={() => setTorch((v) => !v)}><Text style={styles.smallButtonText}>{torch ? 'LIGHT ON' : 'LIGHT'}</Text></Pressable>
            <View style={styles.statusPill}><Text numberOfLines={1} style={styles.statusText}>{paused ? `SAVED: ${lastSaved}` : 'Aim at SAP batch label barcode'}</Text></View>
          </View>
        </View>

        <View style={styles.listHeader}>
          <Text style={styles.listTitle}>Recent Scans</Text>
          <Text style={styles.listHint}>Newest first • long-press to delete</Text>
        </View>
        <FlatList
          data={scans}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => <ScanRow scan={item} onDeleted={refresh} />}
          ListEmptyComponent={<Text style={styles.empty}>Scan your first SAP label.</Text>}
        />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  cameraWrap: { height: 250, backgroundColor: '#16181d', overflow: 'hidden' },
  permissionBox: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 20 },
  permissionTitle: { color: '#fff', fontSize: 16, fontWeight: '800', marginBottom: 14 },
  muted: { color: '#989ca6' },
  button: { backgroundColor: '#fff', borderRadius: 10, paddingHorizontal: 18, paddingVertical: 11 },
  buttonText: { color: '#111318', fontWeight: '900' },
  frame: { position: 'absolute', left: 34, right: 34, top: 62, height: 96, borderWidth: 2, borderColor: '#fff', borderRadius: 12 },
  cameraControls: { position: 'absolute', left: 12, right: 12, bottom: 12, flexDirection: 'row', gap: 8 },
  smallButton: { backgroundColor: 'rgba(0,0,0,.72)', borderRadius: 9, paddingHorizontal: 12, justifyContent: 'center' },
  smallButtonText: { color: '#fff', fontSize: 11, fontWeight: '800' },
  statusPill: { flex: 1, backgroundColor: 'rgba(0,0,0,.72)', borderRadius: 9, paddingHorizontal: 12, paddingVertical: 10 },
  statusText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  listHeader: { paddingHorizontal: 16, paddingTop: 14, paddingBottom: 8 },
  listTitle: { color: '#fff', fontSize: 17, fontWeight: '800' },
  listHint: { color: '#7f838d', fontSize: 10, marginTop: 2 },
  empty: { color: '#8f939e', padding: 18 },
});
