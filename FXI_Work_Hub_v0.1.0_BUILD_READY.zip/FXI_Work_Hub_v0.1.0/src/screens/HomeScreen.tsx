import React, { useCallback, useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Screen } from '../components/Layout';
import { ScanRow } from '../components/ScanRow';
import { getCounts, getRecentScans } from '../lib/db';
import type { BarcodeScan, TabKey } from '../types';

export function HomeScreen({ goTo }: { goTo: (tab: TabKey) => void }) {
  const [counts, setCounts] = useState({ scans: 0, notes: 0, files: 0 });
  const [recent, setRecent] = useState<BarcodeScan[]>([]);

  const refresh = useCallback(async () => {
    setCounts(await getCounts());
    setRecent(await getRecentScans(5));
  }, []);

  useEffect(() => { void refresh(); }, [refresh]);

  return (
    <Screen title="Dashboard">
      <ScrollView contentContainerStyle={styles.content}>
        <Pressable style={styles.primary} onPress={() => goTo('scan')}>
          <Text style={styles.primaryTitle}>SCAN SAP BARCODE</Text>
          <Text style={styles.primarySub}>Saved automatically • newest shown first</Text>
        </Pressable>

        <View style={styles.stats}>
          <Stat label="Scans" value={counts.scans} />
          <Stat label="Notes" value={counts.notes} />
          <Stat label="Files" value={counts.files} />
        </View>

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Most Recent Scans</Text>
          <Pressable onPress={() => goTo('scan')}><Text style={styles.link}>View all</Text></Pressable>
        </View>
        <View style={styles.card}>
          {recent.length === 0 ? (
            <Text style={styles.empty}>No barcodes saved yet.</Text>
          ) : recent.map((scan) => <ScanRow key={scan.id} scan={scan} onDeleted={refresh} />)}
        </View>

        <Text style={styles.privacy}>Version 0.1 stores work data locally on this phone.</Text>
      </ScrollView>
    </Screen>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 30 },
  primary: { backgroundColor: '#f2f3f5', borderRadius: 16, padding: 20 },
  primaryTitle: { color: '#101216', fontSize: 19, fontWeight: '900' },
  primarySub: { color: '#535761', marginTop: 6, fontSize: 12 },
  stats: { flexDirection: 'row', gap: 10, marginTop: 12 },
  stat: { flex: 1, backgroundColor: '#17191f', borderRadius: 14, padding: 15 },
  statValue: { color: '#fff', fontSize: 24, fontWeight: '800' },
  statLabel: { color: '#9296a0', fontSize: 11, marginTop: 2 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 24, marginBottom: 9 },
  sectionTitle: { color: '#fff', fontSize: 17, fontWeight: '800' },
  link: { color: '#c7c9d0', fontWeight: '700', fontSize: 12 },
  card: { backgroundColor: '#15171c', borderRadius: 14, overflow: 'hidden' },
  empty: { color: '#8f939e', padding: 18 },
  privacy: { color: '#676b75', textAlign: 'center', fontSize: 11, marginTop: 28 },
});
