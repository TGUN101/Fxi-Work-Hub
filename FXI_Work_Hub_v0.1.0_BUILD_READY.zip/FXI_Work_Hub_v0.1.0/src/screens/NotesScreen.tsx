import React, { useCallback, useEffect, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Screen } from '../components/Layout';
import { addNote, getNotes } from '../lib/db';
import type { WorkNote } from '../types';

export function NotesScreen() {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [notes, setNotes] = useState<WorkNote[]>([]);

  const refresh = useCallback(async () => setNotes(await getNotes()), []);
  useEffect(() => { void refresh(); }, [refresh]);

  const save = async () => {
    if (!body.trim()) return;
    await addNote(title, body);
    setTitle('');
    setBody('');
    await refresh();
  };

  return (
    <Screen title="Notes & Logs">
      <FlatList
        data={notes}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <View style={styles.editor}>
            <TextInput value={title} onChangeText={setTitle} placeholder="Title (optional)" placeholderTextColor="#6f737d" style={styles.titleInput} />
            <TextInput value={body} onChangeText={setBody} placeholder="Type work note, delay, equipment issue, handoff…" placeholderTextColor="#6f737d" multiline style={styles.bodyInput} />
            <Pressable onPress={save} style={[styles.save, !body.trim() && styles.saveDisabled]} disabled={!body.trim()}>
              <Text style={styles.saveText}>SAVE NOTE</Text>
            </Pressable>
            <Text style={styles.section}>Recent Notes</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.note}>
            <Text style={styles.noteTitle}>{item.title}</Text>
            <Text selectable style={styles.noteBody}>{item.body}</Text>
            <Text style={styles.noteTime}>{new Date(item.created_at).toLocaleString()}</Text>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>No notes saved yet.</Text>}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 30 },
  editor: { marginBottom: 4 },
  titleInput: { color: '#fff', backgroundColor: '#17191f', borderRadius: 12, padding: 13, marginBottom: 8 },
  bodyInput: { color: '#fff', backgroundColor: '#17191f', borderRadius: 12, padding: 13, minHeight: 120, textAlignVertical: 'top' },
  save: { backgroundColor: '#f2f3f5', borderRadius: 11, padding: 13, alignItems: 'center', marginTop: 9 },
  saveDisabled: { opacity: 0.35 },
  saveText: { color: '#111318', fontWeight: '900' },
  section: { color: '#fff', fontSize: 17, fontWeight: '800', marginTop: 24, marginBottom: 8 },
  note: { backgroundColor: '#15171c', borderRadius: 13, padding: 14, marginBottom: 9 },
  noteTitle: { color: '#fff', fontSize: 15, fontWeight: '800' },
  noteBody: { color: '#d2d4d9', fontSize: 14, lineHeight: 20, marginTop: 6 },
  noteTime: { color: '#777b85', fontSize: 10, marginTop: 9 },
  empty: { color: '#8f939e', paddingVertical: 18 },
});
