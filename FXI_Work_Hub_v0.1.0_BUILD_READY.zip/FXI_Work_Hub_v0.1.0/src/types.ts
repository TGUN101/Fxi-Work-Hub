export type TabKey = 'home' | 'scan' | 'notes' | 'files';

export type BarcodeScan = {
  id: number;
  value: string;
  format: string;
  scanned_at: number;
};

export type WorkNote = {
  id: number;
  title: string;
  body: string;
  created_at: number;
};

export type WorkFile = {
  id: number;
  kind: 'photo' | 'manual';
  name: string;
  uri: string;
  mime_type: string | null;
  created_at: number;
};
