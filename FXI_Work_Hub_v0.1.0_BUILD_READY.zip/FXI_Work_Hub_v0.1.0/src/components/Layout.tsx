import React from 'react';
import { Platform, StatusBar as RNStatusBar, StyleSheet, Text, View } from 'react-native';

export function Screen({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Text style={styles.kicker}>FXI WORK HUB</Text>
        <Text style={styles.title}>{title}</Text>
      </View>
      <View style={styles.body}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#0b0c0f',
    paddingTop: Platform.OS === 'android' ? RNStatusBar.currentHeight ?? 24 : 24,
  },
  header: {
    paddingHorizontal: 18,
    paddingTop: 14,
    paddingBottom: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#34363d',
  },
  kicker: { color: '#b8bbc5', fontSize: 11, fontWeight: '800', letterSpacing: 1.4 },
  title: { color: '#ffffff', fontSize: 26, fontWeight: '800', marginTop: 3 },
  body: { flex: 1 },
});
