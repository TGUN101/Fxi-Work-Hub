import React from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';
import type { BarcodeScan } from '../types';
import { deleteScan } from '../lib/db';

function when(ms: number) {
  return new Date(ms).toLocaleString();
}

export function ScanRow({ scan, onDeleted }: { scan: BarcodeScan; onDeleted?: () => void }) {
  const remove = () => {
    Alert.alert('Delete scan?', scan.value, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          await deleteScan(scan.id);
          onDeleted?.();
        },
      },
    ]);
  };

  return (
    <Pressable style={styles.row} onLongPress={remove}>
      <View style={styles.dot} />
      <View style={styles.main}>
        <Text selectable style={styles.value}>{scan.value}</Text>
        <Text style={styles.meta}>{scan.format.toUpperCase()}  •  {when(scan.scanned_at)}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 13,
    paddingHorizontal: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#2b2d34',
  },
  dot: { width: 9, height: 9, borderRadius: 10, backgroundColor: '#d7d9df', marginRight: 12 },
  main: { flex: 1 },
  value: { color: '#ffffff', fontSize: 16, fontWeight: '700' },
  meta: { color: '#90949f', fontSize: 11, marginTop: 4 },
});
