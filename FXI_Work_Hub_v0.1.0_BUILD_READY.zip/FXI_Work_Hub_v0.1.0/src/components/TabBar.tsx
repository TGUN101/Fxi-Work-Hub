import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { TabKey } from '../types';

const TABS: Array<{ key: TabKey; label: string; glyph: string }> = [
  { key: 'home', label: 'Home', glyph: '⌂' },
  { key: 'scan', label: 'Scan', glyph: '▣' },
  { key: 'notes', label: 'Notes', glyph: '✎' },
  { key: 'files', label: 'Files', glyph: '▤' },
];

export function TabBar({ active, onChange }: { active: TabKey; onChange: (tab: TabKey) => void }) {
  return (
    <View style={styles.bar}>
      {TABS.map((tab) => {
        const selected = tab.key === active;
        return (
          <Pressable key={tab.key} style={styles.item} onPress={() => onChange(tab.key)}>
            <Text style={[styles.glyph, selected && styles.selected]}>{tab.glyph}</Text>
            <Text style={[styles.label, selected && styles.selected]}>{tab.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  bar: {
    height: 72,
    flexDirection: 'row',
    backgroundColor: '#121419',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: '#34363d',
    paddingBottom: 8,
  },
  item: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  glyph: { color: '#7f8490', fontSize: 22, fontWeight: '800' },
  label: { color: '#7f8490', fontSize: 11, fontWeight: '700', marginTop: 2 },
  selected: { color: '#ffffff' },
});
