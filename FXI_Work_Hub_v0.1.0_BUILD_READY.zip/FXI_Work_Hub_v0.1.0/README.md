# FXI Work Hub v0.1.0

Android-first personal work organizer built with Expo / React Native.

## Included in this starter build

- SAP barcode scanning with the phone camera
- Automatic saving of scan value, barcode type, and timestamp
- Recent scans sorted newest-first
- Duplicate-scan guard so one label is not saved repeatedly while still in view
- Long-press a scan to delete it
- Notes / log entries stored locally
- Take work photos and copy them into the app's private document storage
- Import manuals (PDF, Word, text) and copy them into app storage
- Dashboard counters and five most recent barcode scans
- Local SQLite database; no cloud account required

## Current limitations / next build targets

- File rows are stored and indexed, but v0.1 does not yet include an in-app photo/PDF viewer.
- No scan search/filter yet.
- No daily/night-log grouping yet.
- No PDF report export yet.
- No backup/export/import yet.
- No parsing of SAP batch-label fields beyond saving the raw barcode data.

## Run on Android

Requires Node.js compatible with Expo SDK 57.

```bash
npm install
npx expo start
```

Install/open Expo Go on the Android phone and scan the development QR code.

For a standalone APK later, create an Expo/EAS development or production build after the app features are finalized.

## Data layout

SQLite: `fxi_work_hub.db`

Files are copied under the app document directory:

- `FXIWorkHub/photos/`
- `FXIWorkHub/manuals/`

The database tracks each stored file's name, kind, URI, MIME type, and created timestamp.
