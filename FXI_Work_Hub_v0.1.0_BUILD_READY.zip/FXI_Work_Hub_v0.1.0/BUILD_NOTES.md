# Build notes

## Product direction

The app is intentionally local-first for the first versions. Work photos, notes, manuals, and barcode history should remain available without plant Wi-Fi or cellular service.

## Proposed next milestones

1. Barcode detail screen with optional description / skid / material note.
2. Search scans by barcode, batch number, date, or note.
3. Night Log mode: one log per shift with timestamped entries and attached photos.
4. In-app photo viewer and PDF/manual viewer.
5. Generate/share Night Log PDF.
6. Backup and restore the local database + stored files.
7. Optional SAP label parser once real sample labels/barcode payloads are available.

## Important

This is a personal work tool and is not an official FXI corporate application. Avoid adding proprietary company branding, credentials, or SAP integration until authorization and technical requirements are known.
